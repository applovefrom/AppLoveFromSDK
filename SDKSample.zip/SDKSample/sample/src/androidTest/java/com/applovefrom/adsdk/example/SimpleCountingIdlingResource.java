package com.applovefrom.adsdk.example;

import android.support.annotation.CheckResult;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.test.espresso.IdlingResource;
import android.util.Log;

import com.applovefrom.base.test.TestCallBackManager;

/**
 * Created by tujiantao on 2018/3/8.
 */

public class SimpleCountingIdlingResource implements IdlingResource {



    private final String name;
    @Nullable
    private volatile ResourceCallback callback;

    @CheckResult
    @NonNull
    public static SimpleCountingIdlingResource create(@NonNull String name) {
        return new SimpleCountingIdlingResource(name);
    }

    private SimpleCountingIdlingResource(String name) {
        this.name = name;
        Log.i("SimpleCountingIdlingResource","初始化了");
        TestCallBackManager.setIdleCallback(new Runnable() {
            public void run() {
                Log.i("SimpleCountingIdlingResource","被执行了");
                ResourceCallback callback = SimpleCountingIdlingResource.this.callback;
                if (callback != null) {
                    Log.i("SimpleCountingIdlingResource","将要调用：onTransitionToIdle了 " +
                            "threadId="+Thread.currentThread().getId()+",processName="+Thread
                            .currentThread().getName());
                    callback.onTransitionToIdle();
                    Log.i("SimpleCountingIdlingResource","调用完了：onTransitionToIdle");
                }

            }
        });
    }

    public String getName() {
        return this.name;
    }

    public boolean isIdleNow() {
        return TestCallBackManager.isIdleNow();
    }

    public void registerIdleTransitionCallback(ResourceCallback callback) {
        this.callback = callback;
    }

}