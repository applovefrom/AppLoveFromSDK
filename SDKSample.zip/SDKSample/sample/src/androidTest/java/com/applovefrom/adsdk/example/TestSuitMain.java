package com.applovefrom.adsdk.example;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 * Created by tujiantao on 2018/3/11.
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({ AdvanceAdTest.class,NativeAdTest.class })
public class TestSuitMain {
}
