package com.applovefrom.adsdk.example.bean;

import com.applovefrom.video.core.AppLoveFromNativeVideo;

/**
 * Created by huangdong on 16/8/18.
 */
public class News {

    public AppLoveFromNativeVideo ctNativeVideo;
    public com.applovefrom.base.core.AppLoveFromAdvanceNative ctAdvanceNative;
    public String iconUrl;
    public String title;
    public String desc;
    public String choiceUrl;
    public String buttonStr;
    public boolean isAds = false;

}
