package com.applovefrom.adsdk.example;

/**
 * Created by Vincent
 *
 */
public class AdHolder {
    public static com.applovefrom.base.vo.AdsNativeVO adNativeVO = null;

}
