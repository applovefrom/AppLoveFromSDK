package com.applovefrom.adsdk.example.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.applovefrom.adsdk.example.R;
import com.applovefrom.adsdk.example.SampleApplication;
import com.applovefrom.adsdk.example.config.Config;
import com.applovefrom.base.core.AppLoveFromSDK;
import com.facebook.drawee.view.SimpleDraweeView;
import com.applovefrom.base.utils.SLog;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by longzhang on 7/26/16.
 */
public class MultiAdsFragment extends Fragment {

    private ListView adList;
    private MyApdater myApdater;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.ad_list_layout, null);
        initView(view);
        return view;
    }


    private void initView(View view) {
        adList = (ListView) view.findViewById(R.id.ad_lv);
        myApdater = new MyApdater();
        adList.setAdapter(myApdater);

        loadData();
    }


    public void loadData() {
        AppLoveFromSDK.getNativeAds(10, Config.slotIdMutilAds, getContext(), new com.applovefrom.base.callback.MultiAdsEventListener() {
                public void onMultiNativeAdsSuccessful(List<com.applovefrom.base.core.AppLoveFromAdvanceNative> res) {
                    myApdater.dataList = res;
                    myApdater.notifyDataSetChanged();
                }


                @Override
                public void onReceiveAdFailed(com.applovefrom.base.core.AppLoveFromNative result) {
                    Toast.makeText(SampleApplication.context, "getNativeAds::onReceiveAdFailed::" + result.getErrorsMsg(), Toast.LENGTH_SHORT).show();

                    SLog.d("onReceiveAdFailed:" + result.getErrorsMsg());
                }


                @Override
                public void onAdClicked(com.applovefrom.base.core.AppLoveFromNative result) {

                    super.onAdClicked(result);
                }
            });
    }


    class MyApdater extends BaseAdapter {

        List<com.applovefrom.base.core.AppLoveFromAdvanceNative> dataList = new ArrayList<>();


        @Override
        public int getCount() {
            return dataList.size();
        }


        @Override
        public com.applovefrom.base.core.AppLoveFromAdvanceNative getItem(int i) {
            return dataList.get(i);
        }


        @Override
        public long getItemId(int i) {
            return i;
        }


        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            Group group = null;
            if (group == null){
                view = View.inflate(SampleApplication.context, R.layout.li_native_ad, null);

                group = new Group();
                group.iamge = (SimpleDraweeView) view.findViewById(R.id.iv_icon);
                group.title = (TextView) view.findViewById(R.id.tv_title);
                group.des = (TextView) view.findViewById(R.id.tv_desc);

                view.setTag(group);
            }else{
                group = (Group) view.getTag();
            }

            com.applovefrom.base.core.AppLoveFromAdvanceNative dataItem = getItem(i);
            group.title.setText(dataItem.getTitle());
            group.des.setText(dataItem.getDesc());
            if (!TextUtils.isEmpty(dataItem.getIconUrl())){
                group.iamge.setImageURI(dataItem.getIconUrl());
            }

            dataItem.registeADClickArea(view);

            return view;
        }

        public void setData(List<com.applovefrom.base.core.AppLoveFromAdvanceNative> items) {
            dataList = new ArrayList<>(items);
            notifyDataSetChanged();
        }

        class Group{
            SimpleDraweeView iamge;
            TextView title;
            TextView des;
        }


    }

}
