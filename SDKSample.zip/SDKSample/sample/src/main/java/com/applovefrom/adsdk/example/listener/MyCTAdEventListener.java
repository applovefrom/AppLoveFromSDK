package com.applovefrom.adsdk.example.listener;

import android.util.Log;
import android.widget.Toast;

import com.applovefrom.base.callback.AdEventListener;

public class MyCTAdEventListener extends AdEventListener {

    @Override
    public void onReceiveAdSucceed(com.applovefrom.base.core.AppLoveFromNative result) {
        showMsg("onReceiveAdSucceed");
    }

    @Override
    public void onReceiveAdVoSucceed(com.applovefrom.base.vo.AdsNativeVO result) {
        showMsg("onReceiveAdVoSucceed");
    }

    @Override
    public void onInterstitialLoadSucceed(com.applovefrom.base.core.AppLoveFromNative result) {
        showMsg("onInterstitialLoadSucceed");
    }

    @Override
    public void onReceiveAdFailed(com.applovefrom.base.core.AppLoveFromNative result) {
        showMsg(result.getErrorsMsg());
        Log.i("sdksample", "==error==" + result.getErrorsMsg());
    }

    @Override
    public void onLandpageShown(com.applovefrom.base.core.AppLoveFromNative result) {
        showMsg("onLandpageShown");
    }

    @Override
    public void onAdClicked(com.applovefrom.base.core.AppLoveFromNative result) {
        showMsg("onAdClicked");
    }

    @Override
    public void onAdClosed(com.applovefrom.base.core.AppLoveFromNative result) {
        showMsg("onAdClosed");
    }


    private void showMsg(String msg) {
        showToast(msg);
    }


    public static void showToast(String text) {
        // Toast.makeText(SampleApplication.context, text, Toast.LENGTH_SHORT).show();
    }


    private static Toast toast;

}
