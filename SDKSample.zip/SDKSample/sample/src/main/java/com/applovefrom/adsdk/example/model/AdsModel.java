package com.applovefrom.adsdk.example.model;

import android.net.Uri;
import android.view.View;
import android.widget.TextView;

import com.applovefrom.adsdk.example.R;
import com.applovefrom.adsdk.example.SampleApplication;
import com.applovefrom.adsdk.example.bean.News;
import com.applovefrom.adsdk.example.config.Config;
import com.applovefrom.adsdk.example.listener.MyCTAdEventListener;
import com.applovefrom.base.core.AppLoveFromSDK;
import com.facebook.drawee.view.SimpleDraweeView;
import com.applovefrom.base.core.AppLoveFromError;
import com.applovefrom.video.core.AppLoveFromNativeVideo;
import com.applovefrom.video.core.AppLoveFromVideo;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by huangdong on 16/8/18.
 */
public class AdsModel {
    //单例
    private AdsModel() {
    }

    private static AdsModel adsModel = null;

    public static AdsModel getAdsModel() {
        if (adsModel == null) {
            adsModel = new AdsModel();
        }
        return adsModel;
    }


    //存放数据
    private List<News> commonList = new ArrayList<>();
    private List<News> smallList = new ArrayList<>();
    private List<News> mediaList = new ArrayList<>();
    private List<News> videoList = new ArrayList<>();

    //外界取数据
    public List<News> getCommonList() {
        return new ArrayList<>(commonList);
    }


    public List<News> getSmallList() {
        return new ArrayList<>(smallList);
    }


    public List<News> getMediaList() {
        return new ArrayList<>(mediaList);
    }

    public List<News> getVideoList() {
        return new ArrayList<>(videoList);
    }

    //接口集合
    private List<AdsModelListener> listenerList = new ArrayList<>();

    //接口
    public interface AdsModelListener {
        void onUpdate();
    }


    public void registerListener(AdsModelListener adl) {
        listenerList.add(adl);
    }


    public void removeListener(AdsModelListener adl) {
        listenerList.remove(adl);
    }


    private void notifyDataChange() {
        for (AdsModelListener adsModelListener : listenerList) {
            adsModelListener.onUpdate();   //调其子类
        }
    }


    //请求普通广告
    public void loadCommonData(int l) {
        commonList.clear();

        for (int i = 0; i < l; i++) {
            News news = new News();
            news.iconUrl = "https://lh3.googleusercontent.com/Pzhl8z9sJAQk8e1ZiL_XnX3WZPEminhbw5I0S5nrqmTtzdbzb1TCydGZJ9FoUmlD_WjO=s180";
            news.title = "测试广告title";
            news.desc = "测试广告desc";
            commonList.add(news);
        }

        notifyDataChange();
    }


    //请求窄条广告
    public void loadSmallAds(int m) {
        smallList.clear();

        for (int i = 0; i < m; i++) {

            AppLoveFromSDK.getNativeAd(Config.slotIdNative, SampleApplication.context, new MyCTAdEventListener() {
                        @Override
                        public void onReceiveAdSucceed(com.applovefrom.base.core.AppLoveFromNative result) {
                            if (result == null) {
                                return;
                            }

                            com.applovefrom.base.core.AppLoveFromAdvanceNative ctAdvanceNative = (com.applovefrom.base.core.AppLoveFromAdvanceNative) result;

                            News news = new News();
                            news.isAds = true;
                            news.iconUrl = ctAdvanceNative.getIconUrl();
                            news.title = ctAdvanceNative.getTitle();
                            news.desc = ctAdvanceNative.getDesc();
                            news.ctAdvanceNative = ctAdvanceNative;

                            smallList.add(news);

                            notifyDataChange();

                            super.onReceiveAdSucceed(result);
                        }


                        @Override
                        public void onReceiveAdFailed(com.applovefrom.base.core.AppLoveFromNative result) {

                            super.onReceiveAdFailed(result);
                        }


                        @Override
                        public void onAdClicked(com.applovefrom.base.core.AppLoveFromNative result) {

                            super.onAdClicked(result);
                        }

                    });
        }

    }


    //请求中等广告
    public void loadMediaAds(int n) {
        mediaList.clear();

        for (int i = 0; i < n; i++) {

            AppLoveFromSDK.getNativeAd(Config.slotIdNative, SampleApplication.context,
                    new MyCTAdEventListener() {
                        @Override
                        public void onReceiveAdSucceed(com.applovefrom.base.core.AppLoveFromNative result) {
                            if (result == null) {
                                return;
                            }

                            com.applovefrom.base.core.AppLoveFromAdvanceNative ctAdvanceNative = (com.applovefrom.base.core.AppLoveFromAdvanceNative) result;

                            View layoutView = View.inflate(SampleApplication.context,
                                    R.layout.item_media_advance_ad_list, null);
                            SimpleDraweeView iv_img = (SimpleDraweeView) layoutView.findViewById(
                                    R.id.iv_img);
                            TextView tv_title = (TextView) layoutView.findViewById(R.id.tv_title);
                            TextView tv_desc = (TextView) layoutView.findViewById(R.id.tv_desc);

                            if (ctAdvanceNative != null) {
                                iv_img.setImageURI(Uri.parse(ctAdvanceNative.getIconUrl()));
                                tv_title.setText(ctAdvanceNative.getTitle());
                                tv_desc.setText(ctAdvanceNative.getDesc());

                                ctAdvanceNative.addADLayoutToADContainer(layoutView);
                                // ctAdvanceNative.registeADClickArea(layoutView);
                            }

                            News news = new News();
                            news.isAds = true;
                            news.ctAdvanceNative = ctAdvanceNative;

                            mediaList.add(news);

                            notifyDataChange();

                            super.onReceiveAdSucceed(result);
                        }


                        @Override
                        public void onReceiveAdFailed(com.applovefrom.base.core.AppLoveFromNative result) {
                            super.onReceiveAdFailed(result);
                        }


                        @Override
                        public void onAdClicked(com.applovefrom.base.core.AppLoveFromNative result) {
                            super.onAdClicked(result);
                        }
                    });

        }
    }


    public void loadVideoAds(int h) {
        videoList.clear();

        for (int i = 0; i < h; i++) {

            AppLoveFromVideo.getNativeVideo(SampleApplication.context, Config.slotIdNativeVideo, new com.applovefrom.base.callback.VideoAdLoadListener() {
                @Override
                public void onVideoAdLoadSucceed(com.applovefrom.base.core.AppLoveFromVideo video) {
                    if (video == null) {
                        return;
                    }

                    AppLoveFromNativeVideo ctNativeVideo = (AppLoveFromNativeVideo) video;
                    News news = new News();
                    news.ctNativeVideo = ctNativeVideo;
                    news.isAds = true;
                    videoList.add(news);

                    notifyDataChange();
                }

                @Override
                public void onVideoAdLoadFailed(AppLoveFromError error) {

                }
            });


        }
    }

}


